package com.example.recicheese.Listeners;

import com.example.recicheese.Models.InstructionsResponse;

import java.util.List;

public interface InstructionsListener {
    void didFetch(List<InstructionsResponse> response, String messgae);
    void didError(String message);
}
