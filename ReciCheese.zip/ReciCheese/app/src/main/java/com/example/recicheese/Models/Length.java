package com.example.recicheese.Models;

public class Length {
    public int number;
    public String unit;
}
