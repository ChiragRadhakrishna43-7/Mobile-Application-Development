package com.example.recicheese.Listeners;

public interface RecipeClickListener {
    void onRecipeClicked(String id);
}
