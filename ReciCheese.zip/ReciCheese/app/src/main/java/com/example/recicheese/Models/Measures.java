package com.example.recicheese.Models;

public class Measures {
    public Us us;
    public Metric metric;
}
