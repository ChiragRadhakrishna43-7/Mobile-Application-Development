package com.example.recicheese.Models;

public class Metric {
    public double amount;
    public String unitShort;
    public String unitLong;
}
